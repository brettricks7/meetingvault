// Read.ai data source — VERIFIED against live account 2026-07-23.
//
// Auth: the user's app.read.ai session cookie. All calls use credentials:'include';
// works because manifest host_permissions includes https://api.read.ai/*.
//
// Endpoint map (captured from the web app's own traffic):
//   GET /reports/?sort_direction=desc[&after_time=ISO]   meeting list, paginated
//     -> { next_timestamp, next_page_params, results: [listRow] }
//   GET /sessions/{id}/transcript                        one call, everything:
//     -> { data: { sessionTranscript: { speakers[{name}], summary{text},
//          topicsV2[{text}], actionItems[{text, ownerName}], keyQuestions[{text}],
//          turns[{ speaker{name}, words[{value, startTime, endTime}], isDeleted }] } } }
//   GET /sessions/{id}/chapters
//     -> [ { clip_type, text (title), secondary_text (summary), start_time, end_time } ]

const API_BASE = "https://api.read.ai";

async function fetchJson(url) {
  const res = await fetch(url, { credentials: "include", headers: { Accept: "application/json" } });
  if (res.status === 401 || res.status === 403) {
    throw new Error("Not logged in — open app.read.ai, sign in, then try again.");
  }
  if (!res.ok) throw new Error(`Read AI returned ${res.status}`);
  return res.json();
}

export async function listMeetings({ onProgress } = {}) {
  const meetings = [];
  let afterTime = null;
  for (;;) {
    const url = afterTime
      ? `${API_BASE}/reports/?sort_direction=desc&after_time=${encodeURIComponent(afterTime)}`
      : `${API_BASE}/reports/?sort_direction=desc`;
    const data = await fetchJson(url);
    meetings.push(...(data.results || []));
    onProgress?.(`Found ${meetings.length} meetings…`);
    if (!data.next_timestamp) break;
    afterTime = data.next_timestamp;
  }
  return meetings;
}

export async function getMeetingDetail(sessionId) {
  const [transcriptRes, chapters] = await Promise.all([
    fetchJson(`${API_BASE}/sessions/${sessionId}/transcript`),
    fetchJson(`${API_BASE}/sessions/${sessionId}/chapters`).catch(() => []),
  ]);
  return { transcript: transcriptRes?.data?.sessionTranscript || {}, chapters };
}

function formatClock(epochMs) {
  if (!epochMs) return "";
  return new Date(epochMs).toISOString().slice(11, 19);
}

// listRow comes from listMeetings; detail from getMeetingDetail.
export function normalizeMeeting(listRow, detail) {
  const t = detail.transcript;
  const turns = (t.turns || [])
    .filter((turn) => !turn.isDeleted && turn.words?.length)
    .map((turn) => ({
      speaker: turn.speaker?.name || "Speaker",
      time: formatClock(turn.words[0]?.startTime),
      text: turn.words.map((w) => w.value).join(" "),
    }));
  return {
    id: listRow.id,
    title: listRow.title || "Untitled meeting",
    startTime: listRow.start_time || "",
    endTime: listRow.end_time || "",
    platform: listRow.meeting_platform || "",
    participants: (t.speakers || []).map((s) => s.name).filter(Boolean),
    summary: t.summary?.text || "",
    chapterSummaries: (detail.chapters || [])
      .filter((c) => c.clip_type === "chapter")
      .map((c) => (c.secondary_text ? `**${c.text}** — ${c.secondary_text}` : c.text)),
    actionItems: (t.actionItems || []).map((a) =>
      a.ownerName ? `${a.text} (${a.ownerName})` : a.text
    ),
    keyQuestions: (t.keyQuestions || []).map((q) => q.text),
    topics: (t.topicsV2 || []).map((topic) => topic.text),
    transcript: turns,
  };
}
