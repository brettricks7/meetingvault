// Meeting → export format converters. Input shape is normalized by readai-api.js:
// { id, title, startTime, endTime, participants: [..], transcript: [{speaker, time, text}],
//   summary, chapterSummaries: [..], actionItems: [..], keyQuestions: [..], topics: [..] }

function safeName(title) {
  return (title || "meeting").replaceAll(/[\\/:*?"<>|]/g, "-").slice(0, 80);
}

export function meetingFilename(meeting, ext) {
  const day = (meeting.startTime || "").slice(0, 10) || "undated";
  return `${day} ${safeName(meeting.title)}.${ext}`;
}

export function toMarkdown(meeting) {
  const lines = [`# ${meeting.title || "Untitled meeting"}`, ""];
  lines.push(`- **Date:** ${meeting.startTime || "unknown"}`);
  if (meeting.participants?.length) {
    lines.push(`- **Participants:** ${meeting.participants.join(", ")}`);
  }
  lines.push("");
  if (meeting.summary) {
    lines.push("## Summary", "", meeting.summary, "");
  }
  if (meeting.chapterSummaries?.length) {
    lines.push("## Chapters", "");
    for (const chapter of meeting.chapterSummaries) lines.push(`- ${chapter}`);
    lines.push("");
  }
  if (meeting.actionItems?.length) {
    lines.push("## Action items", "");
    for (const item of meeting.actionItems) lines.push(`- [ ] ${item}`);
    lines.push("");
  }
  if (meeting.keyQuestions?.length) {
    lines.push("## Key questions", "");
    for (const q of meeting.keyQuestions) lines.push(`- ${q}`);
    lines.push("");
  }
  if (meeting.transcript?.length) {
    lines.push("## Transcript", "");
    for (const turn of meeting.transcript) {
      const stamp = turn.time ? ` (${turn.time})` : "";
      lines.push(`**${turn.speaker || "Speaker"}${stamp}:** ${turn.text}`, "");
    }
  }
  return lines.join("\n");
}

export function toTranscriptRows(meeting) {
  return (meeting.transcript || []).map((turn) => ({
    meeting: meeting.title || "",
    date: meeting.startTime || "",
    time: turn.time || "",
    speaker: turn.speaker || "",
    text: turn.text || "",
  }));
}

export function toMeetingIndexRow(meeting) {
  return {
    date: meeting.startTime || "",
    title: meeting.title || "",
    participants: (meeting.participants || []).join("; "),
    action_items: (meeting.actionItems || []).length,
    transcript_turns: (meeting.transcript || []).length,
  };
}
