// MeetingVault popup: one button — "Export all meetings".
//
// Free tier: unlimited export runs, capped at FREE_MEETING_CAP meetings per run.
// The value moment IS the gate: a user with a 200-meeting archive gets a real,
// useful 10-meeting export plus "190 more require the full version". No run
// counting (kit's gate.js unused here), so reviews stay honest.

import { activateLicense, isPro } from "../license.js";
import { download, downloadCSV, timestampedName } from "../exporter.js";
import { listMeetings, getMeetingDetail, normalizeMeeting } from "../readai-api.js";
import { toMarkdown, toTranscriptRows, toMeetingIndexRow } from "../formats.js";

const PRODUCT = {
  name: "MeetingVault for Read AI",
  FREE_MEETING_CAP: 10,
  checkoutUrl: "https://bricks.lemonsqueezy.com/checkout/buy/018dec39-71c1-4f0c-9f21-9b2dad1a49ee",
  helpUrl: "https://brettricks7.github.io/meetingvault/",
};

const $ = (id) => document.getElementById(id);

function setStatus(text) {
  $("status").textContent = text;
}

async function refresh() {
  const pro = await isPro();
  $("pro-badge").classList.toggle("hidden", !pro);
  $("usage-meter").classList.toggle("hidden", pro);
  if (!pro) {
    $("usage-bar").style.setProperty("--fill", "0%");
    $("usage-text").textContent = `Free plan: up to ${PRODUCT.FREE_MEETING_CAP} meetings per export`;
  }
  return { pro };
}

async function exportAll(pro) {
  setStatus("Finding your meetings…");
  const meetingList = await listMeetings({ onProgress: setStatus });
  if (!meetingList.length) {
    throw new Error("No meetings found. Open app.read.ai and sign in first.");
  }

  const cap = pro ? Infinity : PRODUCT.FREE_MEETING_CAP;
  const toExport = meetingList.slice(0, cap);
  const skipped = meetingList.length - toExport.length;

  const markdownParts = [];
  const indexRows = [];
  const transcriptRows = [];
  for (let i = 0; i < toExport.length; i++) {
    setStatus(`Exporting ${i + 1} of ${toExport.length}…`);
    const detail = await getMeetingDetail(toExport[i].id);
    const meeting = normalizeMeeting(toExport[i], detail);
    markdownParts.push(toMarkdown(meeting));
    indexRows.push(toMeetingIndexRow(meeting));
    transcriptRows.push(...toTranscriptRows(meeting));
  }

  download(timestampedName("readai-meetings", "md"), markdownParts.join("\n\n---\n\n"), "text/markdown");
  downloadCSV(timestampedName("readai-meetings-index", "csv"), indexRows);
  if (transcriptRows.length) {
    downloadCSV(timestampedName("readai-transcripts", "csv"), transcriptRows);
  }

  return { exported: toExport.length, skipped };
}

async function main() {
  document.title = PRODUCT.name;
  $("product-name").textContent = PRODUCT.name;
  $("help-link").href = PRODUCT.helpUrl;
  $("primary-action").textContent = "Export all meetings";
  await refresh();

  $("primary-action").addEventListener("click", async () => {
    const { pro } = await refresh();
    $("primary-action").disabled = true;
    try {
      const { exported, skipped } = await exportAll(pro);
      setStatus(
        skipped > 0
          ? `Exported ${exported} meetings. ${skipped} more require the full version.`
          : `Exported ${exported} meetings. Files are in your Downloads folder.`
      );
      if (skipped > 0) $("upgrade-box").classList.remove("hidden");
    } catch (err) {
      setStatus(err.message || "Something went wrong.");
    } finally {
      $("primary-action").disabled = false;
    }
  });

  $("upgrade-button").addEventListener("click", () => {
    chrome.tabs.create({ url: PRODUCT.checkoutUrl });
  });

  $("license-activate").addEventListener("click", async () => {
    const key = $("license-input").value;
    if (!key.trim()) return;
    $("license-status").textContent = "Activating…";
    const result = await activateLicense(key, `chrome-${crypto.randomUUID().slice(0, 8)}`);
    $("license-status").textContent = result.ok ? "Activated. Thank you!" : result.error;
    if (result.ok) await refresh();
  });
}

main();
