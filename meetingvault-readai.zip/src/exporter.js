// Download helpers usable from popup or content-script contexts.

export function toCSV(rows) {
  if (!rows.length) return "";
  const headers = Object.keys(rows[0]);
  const escape = (value) => {
    const s = String(value ?? "");
    return /[",\n]/.test(s) ? `"${s.replaceAll('"', '""')}"` : s;
  };
  const lines = [headers.join(",")];
  for (const row of rows) lines.push(headers.map((h) => escape(row[h])).join(","));
  return lines.join("\n");
}

export function download(filename, text, mime = "text/plain") {
  const blob = new Blob([text], { type: `${mime};charset=utf-8` });
  const url = URL.createObjectURL(blob);
  if (chrome?.downloads?.download) {
    chrome.downloads.download({ url, filename, saveAs: false }, () => {
      setTimeout(() => URL.revokeObjectURL(url), 60_000);
    });
  } else {
    const a = document.createElement("a");
    a.href = url;
    a.download = filename;
    a.click();
    setTimeout(() => URL.revokeObjectURL(url), 60_000);
  }
}

export function downloadJSON(filename, data) {
  download(filename, JSON.stringify(data, null, 2), "application/json");
}

export function downloadCSV(filename, rows) {
  download(filename, toCSV(rows), "text/csv");
}

export function downloadMarkdown(filename, text) {
  download(filename, text, "text/markdown");
}

export function timestampedName(base, ext) {
  const stamp = new Date().toISOString().slice(0, 19).replaceAll(":", "-");
  return `${base}-${stamp}.${ext}`;
}
