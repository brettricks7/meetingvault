// Lemon Squeezy license handling: activate once, validate on a weekly cadence,
// cache entitlement in chrome.storage.sync so it roams with the user.
// Uses only the public license API — no secrets ship in the extension.
// Docs: https://docs.lemonsqueezy.com/help/licensing/license-api

const LS_API = "https://api.lemonsqueezy.com/v1/licenses";
const REVALIDATE_MS = 7 * 24 * 60 * 60 * 1000;

async function getState() {
  const { license } = await chrome.storage.sync.get("license");
  return license || null;
}

async function setState(license) {
  await chrome.storage.sync.set({ license });
}

// Activate a key the user pasted into the popup. Returns { ok, error? }.
export async function activateLicense(key, instanceName) {
  const res = await fetch(`${LS_API}/activate`, {
    method: "POST",
    headers: { "Content-Type": "application/json", Accept: "application/json" },
    body: JSON.stringify({ license_key: key.trim(), instance_name: instanceName }),
  });
  const data = await res.json();
  if (!res.ok || !data.activated) {
    return { ok: false, error: data.error || "Activation failed. Check the key." };
  }
  await setState({
    key: key.trim(),
    instanceId: data.instance?.id,
    status: "active",
    lastValidated: Date.now(),
  });
  return { ok: true };
}

// Cheap check used on every gated action. Revalidates against the API weekly;
// tolerates being offline by trusting the cache until the next successful check.
export async function isPro() {
  const license = await getState();
  if (!license || license.status !== "active") return false;
  if (Date.now() - license.lastValidated < REVALIDATE_MS) return true;
  try {
    const res = await fetch(`${LS_API}/validate`, {
      method: "POST",
      headers: { "Content-Type": "application/json", Accept: "application/json" },
      body: JSON.stringify({ license_key: license.key, instance_id: license.instanceId }),
    });
    const data = await res.json();
    const valid = res.ok && data.valid;
    await setState({ ...license, status: valid ? "active" : "invalid", lastValidated: Date.now() });
    return valid;
  } catch {
    return true; // offline: trust cache, recheck next time
  }
}

export async function deactivateLocal() {
  await chrome.storage.sync.remove("license");
}
